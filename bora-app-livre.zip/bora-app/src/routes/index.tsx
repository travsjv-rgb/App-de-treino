import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { ArrowLeft, BarChart3, Check, ChevronRight, Dumbbell, Home, Lightbulb, LogOut, MessageCircle, Sparkles, TrendingUp, UserRound } from "lucide-react";
import { Area, AreaChart, CartesianGrid, Tooltip, XAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChartContainer, type ChartConfig } from "@/components/ui/chart";
import { Conversation, ConversationContent, ConversationEmptyState, ConversationScrollButton } from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import { PromptInput, PromptInputFooter, PromptInputSubmit, PromptInputTextarea } from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Tool, ToolContent, ToolHeader, ToolInput, ToolOutput, type ToolPart } from "@/components/ai-elements/tool";
import { supabase } from "@/integrations/supabase/client";
import { getBoraData, saveProfile } from "@/lib/bora.functions";
import type { FocusChoice, Routine, RoutineExercise } from "@/lib/bora-types";
import { buildInsights } from "@/lib/bora-insights";
import type { User } from "@supabase/supabase-js";
import { WorkoutScreen, type ChatSeed } from "@/components/bora/workout";
import boraWordmark from "@/assets/bora-wordmark.png";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "BORA — Treine, registre, evolua" },
    { name: "description", content: "Seu treino inteligente, progresso e acompanhamento em um só lugar." },
    { property: "og:title", content: "BORA — Treine, registre, evolua" },
    { property: "og:description", content: "Treinos personalizados e evolução acompanhada por inteligência artificial." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

type Tab = "inicio" | "treino" | "progresso" | "chat" | "perfil";
const focusOptions: Array<{ id: FocusChoice; title: string; text: string }> = [
  { id: "superiores", title: "Foco em superiores", text: "Peitoral, ombros, costas e braços" },
  { id: "inferiores", title: "Foco em inferiores", text: "Pernas no geral" },
  { id: "corpo_inteiro", title: "Treino equilibrado", text: "Divisão normal, sem priorizar pontos fracos" },
];

function Brand({ compact = false }: { compact?: boolean }) {
  const wordmark = <img src={boraWordmark} alt="BORA" className={compact ? "brand-wordmark brand-wordmark-compact" : "brand-wordmark brand-wordmark-full"}/>;
  if (compact) return wordmark;
  return <div className="flex items-center gap-3"><img src="/__l5e/assets-v1/db0a2cd7-4315-4b59-be0d-9b840205093e/bora-mark.png" alt="Símbolo BORA" className="size-12 rounded-md"/><div>{wordmark}<div className="brand-tagline">Treine · registre · evolua</div></div></div>;
}

function Index() {
  const [user, setUser] = useState<User | null>(null);
  const [checking, setChecking] = useState(true);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => { setUser(data.user); setChecking(false); });
    const { data } = supabase.auth.onAuthStateChange((_event, session) => { setUser(session?.user ?? null); setChecking(false); });
    return () => data.subscription.unsubscribe();
  }, []);
  if (checking) return <div className="grid min-h-screen place-items-center"><Brand /></div>;
  if (!user) return <AuthScreen />;
  return <BoraApp user={user} />;
}

function AuthScreen() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false); const [error, setError] = useState(""); const [notice, setNotice] = useState("");
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    const result = mode === "login" ? await supabase.auth.signInWithPassword({ email, password }) : await supabase.auth.signUp({ email, password });
    if (result.error) setError(result.error.message); else if (mode === "signup" && !result.data.session) setNotice("Confira seu e-mail para confirmar a conta.");
    setBusy(false);
  };
  const google = async () => { setBusy(true); const result = await supabase.auth.signInWithOAuth({ provider: "google", options: { redirectTo: window.location.origin } }); if (result.error) { setError(result.error.message); setBusy(false); } };
  return <main className="auth-shell min-h-screen px-6 py-10"><div className="mx-auto flex min-h-[calc(100vh-5rem)] max-w-sm flex-col justify-center">
    <Brand/><div className="mt-16"><span className="eyebrow">SUA EVOLUÇÃO COMEÇA AQUI</span><h1 className="mt-4 text-4xl font-extrabold leading-tight">Treino sério.<br/><span className="text-primary">Progresso real.</span></h1><p className="mt-3 text-sm leading-6 text-muted-foreground">Planejamento inteligente e acompanhamento que evolui com você.</p></div>
    <form onSubmit={submit} className="mt-9 space-y-3"><Input aria-label="E-mail" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="seu@email.com" className="h-12 bg-card"/><Input aria-label="Senha" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Sua senha" className="h-12 bg-card"/>
      {error && <p className="text-sm text-destructive">{error}</p>}{notice && <p className="text-sm text-primary">{notice}</p>}
      <Button disabled={busy} className="h-12 w-full font-bold">{busy ? "Aguarde..." : mode === "login" ? "Entrar" : "Criar conta"}<ChevronRight/></Button>
    </form><div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border"/>ou<span className="h-px flex-1 bg-border"/></div>
    <Button type="button" variant="outline" className="h-12 w-full" onClick={google}>Continuar com Google</Button>
    <button className="mt-7 text-sm text-muted-foreground" onClick={() => setMode(mode === "login" ? "signup" : "login")}>{mode === "login" ? "Ainda não tem conta? Criar agora" : "Já tem uma conta? Entrar"}</button>
  </div></main>;
}

function BoraApp({ user }: { user: User }) {
  const [tab, setTab] = useState<Tab>("inicio"); const [builder, setBuilder] = useState(false); const [focus, setFocus] = useState<FocusChoice | null>(null);
  const [chatSeed, setChatSeed] = useState<ChatSeed | null>(null);
  const getData = useServerFn(getBoraData); const query = useQuery({ queryKey: ["bora-data", user.id], queryFn: () => getData() });
  if (query.isLoading) return <div className="grid min-h-screen place-items-center"><Brand /></div>;
  if (query.error) return <div className="grid min-h-screen place-items-center px-6 text-center"><div><p>Não foi possível carregar sua conta.</p><Button className="mt-4" onClick={() => query.refetch()}>Tentar novamente</Button></div></div>;
  const data = query.data;
  if (!data?.profile?.onboarding_complete) return <Onboarding user={user} onDone={() => query.refetch()} />;
  const openBuilder = () => { setFocus(null); setBuilder(true); };
  return <div className="app-shell mx-auto min-h-screen max-w-md bg-background">
    {builder ? <Builder focus={focus} setFocus={setFocus} close={() => { setBuilder(false); query.refetch(); }} /> : <>
       <header className="app-header sticky top-0 z-20 flex h-16 items-center justify-between border-b border-border bg-background/90 px-5 backdrop-blur"><Brand compact/><button aria-label="Abrir perfil" className="grid size-8 place-items-center rounded-full border border-border bg-card text-muted-foreground transition-colors hover:text-foreground" onClick={() => setTab("perfil")}><UserRound className="size-4"/></button></header>
       <main className="min-h-[calc(100vh-9rem)] px-5 pb-28 pt-6">
        {tab === "inicio" && <HomeScreen name={data.profile.display_name || user.email?.split("@")[0] || "atleta"} routines={data.routines} openBuilder={openBuilder} goWorkout={() => setTab("treino")}/>} 
        {tab === "treino" && <WorkoutScreen routines={data.routines} openBuilder={openBuilder} onChanged={() => query.refetch()} openChat={(seed) => { setChatSeed(seed); setTab("chat"); }}/>} 
        {tab === "progresso" && <ProgressScreen routines={data.routines}/>} 
        {tab === "chat" && <ChatScreen initialMessages={data.messages} seed={chatSeed} clearSeed={() => setChatSeed(null)}/>} 
        {tab === "perfil" && <ProfileScreen user={user} profile={data.profile} openBuilder={openBuilder}/>} 
      </main><BottomNav tab={tab} setTab={setTab}/>
    </>}
  </div>;
}

function Onboarding({ user, onDone }: { user: User; onDone: () => void }) {
  const save = useServerFn(saveProfile); const [name, setName] = useState(String(user.user_metadata?.["full_name"] ?? "")); const [objective, setObjective] = useState("Hipertrofia"); const [experience, setExperience] = useState("Intermediário"); const [days, setDays] = useState(4); const [busy, setBusy] = useState(false);
  const finish = async () => { setBusy(true); await save({ data: { displayName: name || "Atleta", objective, experience, gender: null, phase: objective === "Emagrecimento" ? "cutting" : "manutencao", planSource: "ai", bodyFocus: "geral", trainingDays: days, currentWeight: null } }); onDone(); };
  return <main className="min-h-screen px-6 py-8"><Brand/><div className="mx-auto mt-14 max-w-sm"><span className="eyebrow">PERFIL DE TREINO</span><h1 className="mt-3 text-3xl font-bold">Vamos personalizar seu BORA.</h1><div className="mt-8 space-y-6"><label className="block text-sm text-muted-foreground">Como quer ser chamado?<Input value={name} onChange={(e) => setName(e.target.value)} className="mt-2 h-12 bg-card" placeholder="Seu nome"/></label><Choice label="Qual seu objetivo?" options={["Hipertrofia","Força","Emagrecimento"]} value={objective} setValue={setObjective}/><Choice label="Seu nível atual" options={["Iniciante","Intermediário","Avançado"]} value={experience} setValue={setExperience}/><div><p className="text-sm text-muted-foreground">Quantos dias por semana?</p><div className="mt-2 grid grid-cols-5 gap-2">{[2,3,4,5,6].map((n) => <Button key={n} variant={days === n ? "default" : "outline"} onClick={() => setDays(n)}>{n}x</Button>)}</div></div><Button className="h-12 w-full font-bold" disabled={busy} onClick={finish}>Continuar <ChevronRight/></Button></div></div></main>;
}

function Choice({ label, options, value, setValue }: { label: string; options: string[]; value: string; setValue: (v: string) => void }) { return <div><p className="text-sm text-muted-foreground">{label}</p><div className="mt-2 grid gap-2">{options.map((option) => <Button key={option} variant={value === option ? "default" : "outline"} className="h-11 justify-start" onClick={() => setValue(option)}>{value === option && <Check/>}{option}</Button>)}</div></div>; }

function HomeScreen({ name, routines, openBuilder, goWorkout }: { name: string; routines: Routine[]; openBuilder: () => void; goWorkout: () => void }) {
  const exercises = routines.flatMap((r) => r.exercises);
  const weeklySets = exercises.reduce((total, exercise) => total + exercise.targetSets, 0);
  const today = routines[0];
  const recentVolume = buildVolumeTrend(exercises).slice(-6);
  return <div className="animate-in fade-in slide-in-from-bottom-2 duration-500"><p className="text-sm text-muted-foreground">Bom dia,</p><h1 className="mt-0.5 text-3xl font-bold">{name.split(" ")[0]}!</h1><p className="mt-1 text-sm text-muted-foreground">Pronto para evoluir hoje?</p><section className="workout-card mt-6 overflow-hidden rounded-lg border border-border bg-card"><div className="p-4"><p className="text-[10px] font-bold uppercase text-primary">Treino de hoje</p><h2 className="mt-2 text-lg font-bold">{today?.name ?? "Seu próximo treino"}</h2><p className="mt-1 text-xs text-muted-foreground">{today ? `${today.exercises.length} exercícios` : "Monte seu plano personalizado"}</p><Button className="mt-4 h-10 w-full font-bold" onClick={today ? goWorkout : openBuilder}>{today ? "Iniciar treino" : "Montar com IA"}<ChevronRight/></Button></div></section><section className="mt-6"><h2 className="text-sm font-bold">Resumo da semana</h2><div className="mt-3 grid grid-cols-2 gap-3 rounded-lg border border-border bg-card py-3"><div className="px-3"><b className="text-lg text-primary">{routines.length}</b><p className="text-[10px] text-muted-foreground">Treinos</p></div><div className="px-3"><b className="text-lg">{weeklySets}</b><p className="text-[10px] text-muted-foreground">Séries planejadas</p></div></div></section>{recentVolume.length > 1 && <section className="mt-5 rounded-lg border border-border bg-card p-4"><div className="flex items-start justify-between"><div><h2 className="text-sm font-bold">Sua evolução</h2><p className="mt-1 text-[10px] text-muted-foreground">Volume das últimas sessões</p></div><TrendingUp className="size-4 text-primary"/></div><VolumeChart data={recentVolume} compact/></section>}<button onClick={openBuilder} className="mt-5 flex w-full items-center gap-3 rounded-lg border border-border bg-card p-4 text-left"><Sparkles className="size-4 text-primary"/><span className="flex-1"><strong className="block text-sm">Montar treino com IA</strong><span className="text-[11px] text-muted-foreground">Crie uma divisão ajustada à sua rotina</span></span><ChevronRight className="size-4"/></button></div>;
}


type TrendPoint = { label: string; volume: number; sessions?: number };

const chartConfig = { volume: { label: "Volume", color: "var(--color-primary)" } } satisfies ChartConfig;

function buildVolumeTrend(exercises: Routine["exercises"]): TrendPoint[] {
  const days = new Map<string, TrendPoint>();
  for (const exercise of exercises) for (const session of exercise.history) {
    const date = new Date(session.performedAt);
    const key = date.toISOString().slice(0, 10);
    const current = days.get(key) ?? { label: date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }), volume: 0, sessions: 0 };
    current.volume += session.sets.reduce((total, set) => total + set.weight * set.reps, 0);
    current.sessions = (current.sessions ?? 0) + 1;
    days.set(key, current);
  }
  return [...days.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([, point]) => ({ ...point, volume: Math.round(point.volume) }));
}

function VolumeChart({ data, compact = false }: { data: TrendPoint[]; compact?: boolean }) {
  return <ChartContainer config={chartConfig} className={compact ? "mt-3 h-24 w-full aspect-auto" : "mt-4 h-44 w-full aspect-auto"}><AreaChart data={data} margin={{ top: 8, right: 4, left: 4, bottom: 0 }}><defs><linearGradient id={compact ? "volumeFillCompact" : "volumeFill"} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.35}/><stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0}/></linearGradient></defs>{!compact && <CartesianGrid vertical={false} stroke="var(--color-border)" strokeOpacity={0.55}/>}<XAxis dataKey="label" axisLine={false} tickLine={false} tickMargin={8} fontSize={10}/>{!compact && <Tooltip cursor={{ stroke: "var(--color-border)" }} contentStyle={{ background: "var(--color-card)", border: "1px solid var(--color-border)", borderRadius: "var(--radius)" }} formatter={(value) => [`${Number(value).toLocaleString("pt-BR")} kg`, "Volume"]}/>}<Area type="monotone" dataKey="volume" stroke="var(--color-primary)" strokeWidth={2} fill={`url(#${compact ? "volumeFillCompact" : "volumeFill"})`} dot={{ r: 2, fill: "var(--color-primary)", strokeWidth: 0 }} activeDot={{ r: 4 }}/></AreaChart></ChartContainer>;
}

function ProgressScreen({ routines }: { routines: Routine[] }) {
  const exercises = routines.flatMap((r) => r.exercises);
  const series = exercises.reduce((sum,e) => sum + e.targetSets, 0);
  const trend = buildVolumeTrend(exercises);
  const groupNames = [...new Set(exercises.map((e) => e.muscleGroup))];
  const groups = groupNames.map((name) => ({ name, sets: exercises.filter((e) => e.muscleGroup === name).reduce((sum, e) => sum + e.targetSets, 0) }));
  const maxSets = Math.max(...groups.map((group) => group.sets), 1);
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const groupExercises = selectedGroup ? exercises.filter((e) => e.muscleGroup === selectedGroup) : [];
  const insights = buildInsights(routines);
  return <div><span className="eyebrow">EVOLUÇÃO</span><h1 className="mt-2 text-3xl font-bold">Seu progresso</h1><div className="mt-7 grid grid-cols-2 gap-3"><Stat value={`${routines.length}`} label="treinos por semana"/><Stat value={`${series}`} label="séries planejadas"/></div><section className="mt-7 rounded-lg border border-border bg-card p-4"><div className="flex items-start justify-between"><div><h2 className="font-bold">Volume total</h2><p className="mt-1 text-xs text-muted-foreground">Carga × repetições registradas</p></div><TrendingUp className="size-5 text-primary"/></div>{trend.length > 1 ? <VolumeChart data={trend.slice(-10)}/> : <div className="grid h-36 place-items-center text-center text-xs text-muted-foreground">Registre pelo menos dois treinos para ver a tendência.</div>}</section><section className="mt-8"><div className="flex items-center gap-2"><Lightbulb className="size-4 text-primary"/><h2 className="font-bold">Insights automáticos</h2></div><p className="mt-1 text-xs text-muted-foreground">Detectados a partir dos seus registros, sem IA</p>{insights.length === 0 ? <p className="mt-4 rounded-lg border border-border bg-card p-4 text-xs text-muted-foreground">Nenhum alerta no momento — continue registrando seus treinos.</p> : <div className="mt-4 space-y-3">{insights.map((insight, i) => <article key={i} className="rounded-lg border border-border bg-card p-4"><p className="text-sm font-bold">{insight.title}</p><p className="mt-1 text-xs text-muted-foreground">{insight.detail}</p>{insight.suggestion && <p className="mt-2 rounded-md border border-primary/30 bg-primary/5 p-2.5 text-[11px] leading-4">{insight.suggestion}</p>}</article>)}</div>}</section><section className="mt-8"><h2 className="font-bold">Progressão por grupo muscular</h2><p className="mt-1 text-xs text-muted-foreground">Toque num grupo para ver carga, reps, RIR e metas</p><div className="mt-5 space-y-5">{groups.map((group) => <button key={group.name} className="block w-full text-left" onClick={() => setSelectedGroup(selectedGroup === group.name ? null : group.name)}><div className="mb-2 flex justify-between text-xs"><span className={selectedGroup === group.name ? "font-bold text-primary" : ""}>{group.name}</span><span className="text-muted-foreground">{group.sets} séries</span></div><progress className="muscle-progress" max={maxSets} value={group.sets} aria-label={`${group.name}: ${group.sets} séries`}/></button>)}</div>{selectedGroup && <div className="mt-6 space-y-4">{groupExercises.map((exercise) => <ExerciseProgressionCard key={exercise.id} exercise={exercise}/>)}{groupExercises.length === 0 && <p className="text-xs text-muted-foreground">Nenhum exercício nesse grupo ainda.</p>}</div>}</section></div>;
}

function ExerciseProgressionCard({ exercise }: { exercise: RoutineExercise }) {
  const last = exercise.history.at(-1);
  const prev = exercise.history.at(-2);
  const suggestion = exercise.nextSuggestion;
  const weightTrend = exercise.history.map((session) => ({ label: new Date(session.performedAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }), volume: Math.max(...session.sets.map((s) => s.weight), 0) }));
  const goals = buildProgressionGoals(exercise);
  return <article className="rounded-lg border border-border bg-card p-4">
    <div className="flex items-start justify-between gap-3"><div><h3 className="text-sm font-bold">{exercise.name}</h3><p className="mt-0.5 text-[10px] text-muted-foreground">{exercise.targetSets} séries · {exercise.repMin}–{exercise.repMax} reps · +{exercise.increment} kg por progressão</p></div><b className="text-lg text-primary">{exercise.currentWeight} kg</b></div>
    {weightTrend.length > 1 && <VolumeChart data={weightTrend} compact/>}
    {last ? <div className="mt-3"><p className="text-[10px] font-semibold uppercase text-muted-foreground">Última sessão · {new Date(last.performedAt).toLocaleDateString("pt-BR")}</p><div className="mt-2 grid grid-cols-3 gap-1.5 text-center text-[10px] text-muted-foreground"><span>Série</span><span>Carga × reps</span><span>RIR</span>{last.sets.map((set, i) => <div key={i} className="col-span-3 grid grid-cols-3 gap-1.5 rounded-sm bg-secondary/60 px-2 py-1.5 text-xs"><span className="text-muted-foreground">{i + 1}</span><b>{set.weight} kg × {set.reps}</b><span className={set.rir <= 0 ? "text-destructive" : set.rir >= 2 ? "text-primary" : ""}>{set.rir}</span></div>)}</div>{prev && <p className="mt-2 text-[10px] text-muted-foreground">Anterior: {Math.max(...prev.sets.map((s) => s.weight))} kg × {Math.max(...prev.sets.map((s) => s.reps))} reps</p>}</div> : <p className="mt-3 text-xs text-muted-foreground">Sem registros ainda — a primeira sessão define a linha de base.</p>}
    {suggestion && <div className="mt-3 rounded-md border border-primary/30 bg-primary/5 p-3"><p className="text-[10px] font-bold uppercase text-primary">Próxima sessão</p><p className="mt-1 text-xs"><b>{suggestion.weight} kg</b> · alvo de {suggestion.repsTarget} reps</p><p className="mt-1 text-[11px] leading-4 text-muted-foreground">{suggestion.reason}</p></div>}
    <div className="mt-3"><p className="text-[10px] font-semibold uppercase text-muted-foreground">Plano de progressão</p><ol className="mt-2 space-y-2">{goals.map((goal, i) => <li key={i} className="flex items-start gap-2 text-xs"><span className={`mt-0.5 grid size-4 shrink-0 place-items-center rounded-full text-[9px] font-bold ${goal.done ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"}`}>{goal.done ? <Check className="size-2.5"/> : i + 1}</span><span className={goal.done ? "text-muted-foreground line-through" : ""}>{goal.text}</span></li>)}</ol></div>
  </article>;
}

function buildProgressionGoals(exercise: RoutineExercise): Array<{ text: string; done: boolean }> {
  if (exercise.isCardio) {
    const lastReps = Math.max(...(exercise.history.at(-1)?.sets.map((s) => s.reps) ?? [0]), 0);
    return [
      { text: `Sustentar ${Math.max(lastReps, exercise.repMin)} min por sessão`, done: lastReps >= exercise.repMin },
      { text: `Confirmar esforço confortável (RIR ≥ 2) por 2 sessões seguidas`, done: false },
      { text: `Subir para ${exercise.currentWeight + exercise.increment} de intensidade/duração`, done: false },
    ];
  }
  const last = exercise.history.at(-1);
  const hitCeiling = !!last && last.sets.every((s) => s.reps >= exercise.repMax);
  const comfortable = !!last && last.sets.reduce((a, s) => a + s.rir, 0) / last.sets.length >= 2;
  return [
    { text: `Bater ${exercise.repMax} reps em todas as séries com ${exercise.currentWeight} kg`, done: hitCeiling },
    { text: `Repetir o teto com folga (RIR ≥ 2) por 2 sessões seguidas`, done: hitCeiling && comfortable },
    { text: `Subir para ${exercise.currentWeight + exercise.increment} kg na faixa de ${exercise.repMin}–${exercise.repMax} reps`, done: false },
    { text: `Meta de médio prazo: ${exercise.currentWeight + exercise.increment * 4} kg`, done: false },
  ];
}

function Stat({ value, label }: { value: string; label: string }) { return <div className="rounded-md border border-border bg-card p-4"><b className="text-3xl text-primary">{value}</b><p className="mt-1 text-xs text-muted-foreground">{label}</p></div>; }

function ChatScreen({ initialMessages, seed, clearSeed }: { initialMessages: UIMessage[]; seed: ChatSeed | null; clearSeed: () => void }) { return <AIChat mode="main" initialMessages={initialMessages} seed={seed} clearSeed={clearSeed} title="Assistente BORA" subtitle="Seu acompanhamento contínuo"/>; }

function Builder({ focus, setFocus, close }: { focus: FocusChoice | null; setFocus: (focus: FocusChoice) => void; close: () => void }) {
  const initial = useMemo<UIMessage[]>(() => focus ? [{ id: `focus-${focus}`, role: "user", parts: [{ type: "text", text: focusOptions.find((item) => item.id === focus)?.title ?? focus }] }] : [], [focus]);
  return <div className="flex h-screen flex-col"><header className="flex h-18 shrink-0 items-center gap-3 border-b border-border px-4"><Button size="icon" variant="ghost" onClick={close} aria-label="Voltar"><ArrowLeft/></Button><div><b>Montar com IA</b><p className="text-xs text-muted-foreground">Conversa temporária</p></div></header>{!focus ? <div className="flex flex-1 flex-col px-5 py-8"><div className="grid size-12 place-items-center rounded-md bg-primary text-primary-foreground"><Sparkles/></div><h1 className="mt-6 text-3xl font-bold">Onde você quer focar?</h1><p className="mt-2 text-sm leading-6 text-muted-foreground">Escolha um ponto de partida. Depois eu ajusto tudo com você.</p><div className="mt-8 space-y-3">{focusOptions.map((option) => <button key={option.id} onClick={() => setFocus(option.id)} className="group flex w-full items-center gap-4 rounded-md border border-border bg-card p-4 text-left transition hover:border-primary"><span className="grid size-10 place-items-center rounded-sm bg-secondary text-primary"><Dumbbell className="size-5"/></span><span className="flex-1"><b className="block text-sm">{option.title}</b><span className="text-xs text-muted-foreground">{option.text}</span></span><ChevronRight className="size-4 text-muted-foreground group-hover:text-primary"/></button>)}</div></div> : <AIChat key={focus} mode="builder" focus={focus} initialMessages={initial} title="Montando seu treino" subtitle={focusOptions.find((item) => item.id === focus)?.title ?? "Personalizado"}/>}</div>;
}

function AIChat({ mode, focus, initialMessages, title, subtitle, seed, clearSeed }: { mode: "main"|"builder"; focus?: string; initialMessages: UIMessage[]; title: string; subtitle: string; seed?: ChatSeed | null; clearSeed?: () => void }) {
  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const contextRef = useRef<string | undefined>(seed?.context);
  const transport = useMemo(() => new DefaultChatTransport({ api: "/api/chat", headers: async () => { const { data } = await supabase.auth.getSession(); return data.session ? { Authorization: `Bearer ${data.session.access_token}` } : {}; }, body: () => ({ mode, focus, workoutContext: contextRef.current }) }), [mode, focus]);
  const { messages, sendMessage, status, error } = useChat({ messages: initialMessages, transport });
  useEffect(() => { if (seed) { contextRef.current = seed.context; void sendMessage({ text: seed.prompt }); clearSeed?.(); } }, []);
  useEffect(() => { if (mode === "builder" && initialMessages.length === 1 && messages.length === 1) void sendMessage(undefined); }, []);
  useEffect(() => { if (status === "ready") inputRef.current?.focus(); }, [status]);
  const ask = (text: string) => { if (status !== "ready") return; setInput(""); void sendMessage({ text }); inputRef.current?.focus(); };
  const submit = () => { const value = input.trim(); if (!value) return; ask(value); };
  const quickPrompts = ["Analise meu treino", "Estou estagnado?", "Como está meu volume?", "Preciso de um treino mais rápido"];
  return <div className="flex min-h-0 flex-1 flex-col"><div className="border-b border-border px-5 py-4"><span className="eyebrow">{title}</span><p className="mt-1 text-xs text-muted-foreground">{subtitle}</p></div><Conversation><ConversationContent className="gap-5 px-5 py-6">{messages.length === 0 && <><ConversationEmptyState icon={<TrendingUp className="size-8 text-primary"/>} title="Como posso ajudar?" description="Pergunte sobre seu treino, carga, volume ou recuperação."/>{mode === "main" && <div className="grid grid-cols-2 gap-2">{quickPrompts.map((prompt) => <Button key={prompt} type="button" variant="outline" className="h-auto min-h-11 justify-start whitespace-normal px-3 py-2 text-left text-xs" onClick={() => ask(prompt)}>{prompt}</Button>)}</div>}</>}{messages.map((message) => <Message key={message.id} from={message.role}><MessageContent>{message.parts.map((part,index) => {
    if (part.type === "text") return <MessageResponse key={index}>{part.text}</MessageResponse>;
    if (part.type.startsWith("tool-")) { const toolPart = part as ToolPart; return <Tool key={index} defaultOpen={false}><ToolHeader type={toolPart.type as `tool-${string}`} state={toolPart.state} title="Atualizar plano"/><ToolContent><ToolInput input={toolPart.input}/><ToolOutput output={toolPart.output} errorText={toolPart.errorText}/></ToolContent></Tool>; }
    return null;
  })}</MessageContent></Message>)}{status !== "ready" && <Shimmer className="text-xs">Analisando seu histórico...</Shimmer>}{error && <p className="rounded-md border border-destructive/40 p-3 text-sm text-destructive">{error.message}</p>}</ConversationContent><ConversationScrollButton/></Conversation><div className="border-t border-border bg-background p-4"><PromptInput onSubmit={() => submit()} className="bg-card"><PromptInputTextarea ref={inputRef} autoFocus value={input} onChange={(e) => setInput(e.target.value)} placeholder="Pergunte algo..."/><PromptInputFooter className="justify-end"><PromptInputSubmit status={status} disabled={!input.trim() || status !== "ready"}/></PromptInputFooter></PromptInput></div></div>;
}

function ProfileScreen({ user, profile, openBuilder }: { user: User; profile: { display_name: string; objective: string; experience: string; training_days: number }; openBuilder: () => void }) { return <div><span className="eyebrow">SUA CONTA</span><h1 className="mt-2 text-3xl font-bold">Perfil</h1><div className="mt-8 flex items-center gap-4 border-y border-border py-5"><span className="grid size-14 place-items-center rounded-full bg-primary text-xl font-bold text-primary-foreground">{(profile.display_name || user.email || "A")[0]?.toUpperCase()}</span><div><b>{profile.display_name || "Atleta"}</b><p className="text-xs text-muted-foreground">{user.email}</p></div></div><div className="divide-y divide-border">{[["Objetivo",profile.objective],["Experiência",profile.experience],["Frequência",`${profile.training_days}x por semana`]].map(([a,b]) => <div key={a} className="flex justify-between py-4 text-sm"><span className="text-muted-foreground">{a}</span><b>{b}</b></div>)}</div><Button variant="outline" className="mt-6 h-11 w-full" onClick={openBuilder}><Sparkles/>Remontar treino com IA</Button><Button variant="ghost" className="mt-3 h-11 w-full text-destructive" onClick={() => supabase.auth.signOut()}><LogOut/>Sair da conta</Button></div>; }
function Empty({ title, text, action, onClick }: { title: string; text: string; action: string; onClick: () => void }) { return <div className="grid min-h-[65vh] place-items-center text-center"><div><div className="mx-auto grid size-14 place-items-center rounded-md bg-primary text-primary-foreground"><Sparkles/></div><h1 className="mt-5 text-2xl font-bold">{title}</h1><p className="mx-auto mt-2 max-w-xs text-sm leading-6 text-muted-foreground">{text}</p><Button className="mt-6" onClick={onClick}>{action}<ChevronRight/></Button></div></div>; }
function BottomNav({ tab, setTab }: { tab: Tab; setTab: (tab: Tab) => void }) { const items: Array<{ id: Tab; label: string; icon: typeof Home }> = [{id:"inicio",label:"Início",icon:Home},{id:"treino",label:"Treino",icon:Dumbbell},{id:"progresso",label:"Progresso",icon:BarChart3},{id:"chat",label:"Assistente",icon:MessageCircle},{id:"perfil",label:"Perfil",icon:UserRound}]; return <nav className="fixed bottom-0 left-1/2 z-30 flex h-20 w-full max-w-md -translate-x-1/2 items-center justify-around border-t border-border bg-background/95 px-2 backdrop-blur">{items.map(({id,label,icon:Icon}) => <button key={id} onClick={() => setTab(id)} className={`flex min-w-14 flex-col items-center gap-1 text-[10px] font-semibold ${tab === id ? "text-primary" : "text-muted-foreground"}`}><Icon className="size-5"/><span>{label}</span></button>)}</nav>; }
