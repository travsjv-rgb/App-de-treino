import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { convertToModelMessages, isStepCount, streamText, tool, type UIMessage } from "ai";
import { z } from "zod";
import { createBoraAI } from "@/lib/ai-gateway.server";
import { AI_PERSONA } from "@/lib/bora-progression";
import type { Database } from "@/integrations/supabase/types";

const exerciseSchema = z.object({
  name: z.string(),
  muscleGroup: z.string(),
  isCardio: z.boolean().default(false),
  sets: z.number(),
  repMin: z.number(),
  repMax: z.number(),
  startingWeight: z.number(),
  increment: z.number().default(2.5),
});
const routineSchema = z.object({ name: z.string(), exercises: z.array(exerciseSchema) });
const planSchema = z.object({ routines: z.array(routineSchema) });
type ChatBody = { messages?: unknown; mode?: "main" | "builder"; focus?: string; workoutContext?: string };

export const Route = createFileRoute("/api/chat")({
  server: { handlers: { POST: async ({ request }) => {
    const authorization = request.headers.get("authorization");
    const token = authorization?.startsWith("Bearer ") ? authorization.slice(7) : null;
    if (!token) return Response.json({ error: "Entre na sua conta para conversar com a assistente." }, { status: 401 });
    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    const aiKey = process.env["GEMINI_API_KEY"];
    if (!url || !key || !aiKey) return Response.json({ error: "A assistente ainda não está configurada (falta a GEMINI_API_KEY nas variáveis de ambiente)." }, { status: 500 });
    const supabase = createClient<Database>(url, key, { global: { headers: { Authorization: `Bearer ${token}` } }, auth: { persistSession: false, autoRefreshToken: false } });
    const claims = await supabase.auth.getClaims(token);
    const userId = claims.data?.claims?.sub;
    if (!userId) return Response.json({ error: "Sua sessão expirou. Entre novamente." }, { status: 401 });
    const body = await request.json() as ChatBody;
    if (!Array.isArray(body.messages)) return Response.json({ error: "Mensagem inválida." }, { status: 400 });
    const messages = body.messages as UIMessage[];
    const mode = body.mode === "builder" ? "builder" : "main";
    const latestUser = [...messages].reverse().find((message) => message.role === "user");
    const latestContent = latestUser?.parts.filter((part) => part.type === "text").map((part) => part.text).join("") ?? "";
    const [profileResult, routinesResult, messageSaveResult, sessionsResult] = await Promise.all([
      supabase.from("profiles").select("*").eq("user_id", userId).maybeSingle(),
      supabase.from("routines").select("id, name, order_index, routine_exercises(name, muscle_group, target_sets, rep_min, rep_max, current_weight, next_suggestion)").eq("user_id", userId).order("order_index"),
      mode === "main" && latestUser
        ? supabase.from("chat_messages").insert({ user_id: userId, role: "user", content: latestContent, message_parts: latestUser.parts as never })
        : Promise.resolve({ error: null }),
      supabase.from("exercise_sessions").select("performed_at, sets, routine_exercises(name)").eq("user_id", userId).order("performed_at", { ascending: false }).limit(40),
    ]);
    if (profileResult.error || routinesResult.error || messageSaveResult.error) return Response.json({ error: profileResult.error?.message ?? routinesResult.error?.message ?? messageSaveResult.error?.message }, { status: 500 });
    const profile = profileResult.data;
    const currentRoutines = routinesResult.data ?? [];
    const history = (sessionsResult.data ?? []).map((row: any) => `${row.performed_at.slice(0, 10)} ${row.routine_exercises?.name ?? "?"}: ${(row.sets as Array<{ weight: number; reps: number; rir: number }>).map((x) => `${x.weight}kg×${x.reps}@RIR${x.rir}`).join(", ")}`).join("\n");
    const live = typeof body.workoutContext === "string" ? body.workoutContext.slice(0, 2000) : "";
    const ai = createBoraAI(aiKey);
    const focusInstruction = body.focus === "corpo_inteiro"
      ? "O usuário escolheu treinar o corpo todo de forma equilibrada: monte uma divisão semanal convencional (por exemplo upper/lower, push-pull-legs ou ABC conforme a frequência), distribuindo todos os grupos sem priorizar pontos fracos."
      : `Preferência de foco corporal: ${body.focus ?? "a descobrir"}.`;
    const system = `${AI_PERSONA}

Fale em português brasileiro, de forma direta, acolhedora e prática. Nunca faça diagnóstico médico. Perfil do usuário: ${JSON.stringify(profile ?? {})}. Rotinas atuais (com exercícios e sugestões de progressão): ${JSON.stringify(currentRoutines)}. Histórico recente registrado (mais novo primeiro):\n${history || "nenhum registro ainda"}\n${live ? `${live} Adapte o treino de hoje sem prejudicar a progressão registrada; prefira trocar isoladores redundantes por alternativas do mesmo padrão de movimento.\n` : ""}${mode === "builder" ? `Você está numa conversa pra montar o(s) treino(s) do usuário. ${focusInstruction} Faça no máximo uma pergunta curta por vez sobre dias disponíveis, experiência, equipamentos, limitações e duração. Defina o volume inicial por grupo muscular com base em evidência (iniciante ~8-10 séries/semana por grupo, intermediário ~10-14, avançado ~14-18; ajuste pela fase — reduza em cutting, pode aumentar em bulk). Quando tiver dados suficientes, apresente um resumo compacto e pergunte se pode salvar. SOMENTE após confirmação explícita, chame salvar_rotinas — uma rotina por dia de treino.` : "Use as rotinas atuais e o histórico de cada exercício (RIR, reps, carga) pra acompanhar evolução, seguindo a política de progressão: só confirme aumento de carga depois de 2 sessões seguidas batendo o teto da faixa de reps com folga; caso contrário, oriente um alvo concreto de reps. Se o usuário pedir mudanças no plano, explique e só chame salvar_rotinas após confirmação explícita."}`;
    const result = streamText({
      model: ai.model, system,
      messages: await convertToModelMessages(messages), stopWhen: isStepCount(50),
      tools: { salvar_rotinas: tool({
        description: "Salva no BORA uma ou mais rotinas de treino que o usuário confirmou explicitamente. Substitui as rotinas atuais.",
        inputSchema: planSchema,
        execute: async (plan) => {
          await supabase.from("routines").delete().eq("user_id", userId);
          let totalExercises = 0;
          for (let i = 0; i < plan.routines.length; i++) {
            const routine = plan.routines[i];
            if (!routine) continue;
            const { data: inserted, error: routineError } = await supabase
              .from("routines")
              .insert({ user_id: userId, name: routine.name, order_index: i })
              .select()
              .single();
            if (routineError || !inserted) throw new Error(routineError?.message ?? "falha ao criar rotina");
            const rows = routine.exercises.map((ex, j) => ({
              routine_id: inserted.id,
              user_id: userId,
              name: ex.name,
              muscle_group: ex.muscleGroup,
              is_cardio: ex.isCardio,
              current_weight: ex.startingWeight,
              target_sets: ex.sets,
              rep_min: ex.repMin,
              rep_max: ex.repMax,
              increment: ex.increment,
              order_index: j,
            }));
            const { error: exercisesError } = await supabase.from("routine_exercises").insert(rows);
            if (exercisesError) throw new Error(exercisesError.message);
            totalExercises += rows.length;
          }
          return { success: true, message: "Rotinas salvas no BORA", routines: plan.routines.length, exercises: totalExercises };
        },
      }) },
    });
    return result.toUIMessageStreamResponse({ originalMessages: messages, sendReasoning: true,
      onFinish: async ({ responseMessage }) => {
        if (mode !== "main") return;
        const content = responseMessage.parts.filter((part) => part.type === "text").map((part) => part.text).join("");
        const saved = await supabase.from("chat_messages").insert({ user_id: userId, role: "assistant", content, message_parts: responseMessage.parts as never });
        if (saved.error) console.error("Could not save assistant message", saved.error.message);
      },
    });
  } } },
});

