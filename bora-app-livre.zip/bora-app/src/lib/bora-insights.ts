import type { Routine, RoutineExercise } from "./bora-types";
import { isStagnant } from "./bora-progression";
import { EXERCISE_CATALOG } from "./bora-exercises";

export type InsightKind = "estagnacao" | "queda_volume" | "troca_variacao";

export type Insight = {
  kind: InsightKind;
  title: string;
  detail: string;
  exerciseName?: string;
  muscleGroup?: string;
  suggestion?: string;
};

function bestWeight(exercise: RoutineExercise): number {
  return Math.max(0, ...exercise.history.map((h) => Math.max(0, ...h.sets.map((s) => s.weight))));
}

function sessionVolume(exercise: RoutineExercise): { date: string; sets: number }[] {
  return exercise.history.map((h) => ({ date: h.performedAt, sets: h.sets.length }));
}

/** Insights 100% determinísticos, sem custo de IA. */
export function buildInsights(routines: Routine[]): Insight[] {
  const insights: Insight[] = [];
  const exercises = routines.flatMap((r) => r.exercises);

  // 1. Estagnação por exercício
  for (const ex of exercises) {
    if (ex.isCardio || ex.history.length < 3) continue;
    if (!isStagnant(ex)) continue;
    const weight = bestWeight(ex);
    const catalogEntry = EXERCISE_CATALOG.find((c) => c.name === ex.name);
    const alternative = catalogEntry?.variations.find((v) => v !== ex.name);
    insights.push({
      kind: "estagnacao",
      title: `${ex.name} estagnado`,
      detail: `Mesma carga (${weight}kg) nas últimas 3 sessões sem confirmar o teto de reps.`,
      exerciseName: ex.name,
      muscleGroup: ex.muscleGroup,
      suggestion: alternative
        ? `Troque a variação: experimente "${alternative}" para estimular ${ex.muscleGroup} por outro ângulo.`
        : "Revise o volume semanal e a recuperação (sono, alimentação) antes de forçar carga.",
    });
  }

  // 2. Queda de volume por grupo muscular (últimas 2 semanas vs 2 anteriores)
  const byGroup = new Map<string, RoutineExercise[]>();
  for (const ex of exercises) {
    const list = byGroup.get(ex.muscleGroup) ?? [];
    list.push(ex);
    byGroup.set(ex.muscleGroup, list);
  }
  const now = Date.now();
  const WEEK = 7 * 24 * 60 * 60 * 1000;
  for (const [group, list] of byGroup) {
    let recent = 0;
    let previous = 0;
    for (const ex of list) {
      for (const s of sessionVolume(ex)) {
        const age = now - new Date(s.date).getTime();
        if (age <= 2 * WEEK) recent += s.sets;
        else if (age <= 4 * WEEK) previous += s.sets;
      }
    }
    if (previous >= 6 && recent < previous * 0.7) {
      insights.push({
        kind: "queda_volume",
        title: `Volume de ${group} caiu`,
        detail: `De ${previous} para ${recent} séries nas últimas 2 semanas (queda de ${Math.round((1 - recent / previous) * 100)}%).`,
        muscleGroup: group,
        suggestion: `Inclua 1-2 séries a mais de ${group} na próxima semana para retomar o volume.`,
      });
    }
  }

  // 3. Sugestão de troca de variação para exercícios com RIR muito baixo recorrente
  for (const ex of exercises) {
    if (ex.isCardio || ex.history.length < 2) continue;
    const lastTwo = ex.history.slice(-2);
    const grinding = lastTwo.every((h) => h.sets.some((s) => s.rir === 0));
    if (!grinding) continue;
    const catalogEntry = EXERCISE_CATALOG.find((c) => c.name === ex.name);
    const alternative = catalogEntry?.variations.find((v) => v !== ex.name);
    if (!alternative) continue;
    insights.push({
      kind: "troca_variacao",
      title: `${ex.name}: falha recorrente`,
      detail: "Você chegou à falha (RIR 0) nas últimas 2 sessões — sinal de fadiga acumulada nesse padrão.",
      exerciseName: ex.name,
      muscleGroup: ex.muscleGroup,
      suggestion: `Considere trocar por "${alternative}" por algumas semanas e depois retomar.`,
    });
  }

  return insights;
}
