import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { fallbackProgression } from "@/lib/bora-progression";
import type { ExerciseSession, ProgressionSuggestion, Routine, RoutineExercise, SetEntry } from "@/lib/bora-types";

const profileSchema = z.object({
  displayName: z.string(),
  objective: z.string(),
  experience: z.string(),
  gender: z.enum(["masculino", "feminino", "prefiro_nao_dizer"]).nullable(),
  phase: z.enum(["cutting", "manutencao", "bulk"]),
  planSource: z.enum(["manual", "ai"]),
  bodyFocus: z.enum(["superior", "inferior", "geral"]),
  trainingDays: z.number(),
  currentWeight: z.number().nullable(),
});

const setEntrySchema = z.object({ weight: z.number(), reps: z.number(), rir: z.number().min(0).max(4) });

const HISTORY_LIMIT_PER_EXERCISE = 10;

/** Monta as rotinas completas (com exercícios e histórico recente) a partir das linhas do banco. */
async function loadRoutines(supabase: any, userId: string): Promise<Routine[]> {
  const { data: routineRows, error: routinesError } = await supabase
    .from("routines").select("*").eq("user_id", userId).order("order_index");
  if (routinesError) throw new Error(routinesError.message);

  const { data: exerciseRows, error: exercisesError } = await supabase
    .from("routine_exercises").select("*").eq("user_id", userId).order("order_index");
  if (exercisesError) throw new Error(exercisesError.message);

  const exerciseIds = (exerciseRows ?? []).map((e: any) => e.id);
  let sessionsByExercise: Record<string, ExerciseSession[]> = {};
  if (exerciseIds.length) {
    const { data: sessionRows, error: sessionsError } = await supabase
      .from("exercise_sessions").select("*").in("routine_exercise_id", exerciseIds).order("performed_at", { ascending: true });
    if (sessionsError) throw new Error(sessionsError.message);
    for (const row of sessionRows ?? []) {
      const list = sessionsByExercise[row.routine_exercise_id] ?? (sessionsByExercise[row.routine_exercise_id] = []);
      list.push({ id: row.id, performedAt: row.performed_at, sets: row.sets as SetEntry[] });
    }
    // mantém só as últimas N sessões por exercício em memória (suficiente pra UI e pra progressão)
    for (const id of Object.keys(sessionsByExercise)) {
      sessionsByExercise[id] = (sessionsByExercise[id] ?? []).slice(-HISTORY_LIMIT_PER_EXERCISE);
    }
  }

  const exercisesByRoutine: Record<string, RoutineExercise[]> = {};
  for (const row of exerciseRows ?? []) {
    const exercise: RoutineExercise = {
      id: row.id, routineId: row.routine_id, name: row.name, muscleGroup: row.muscle_group,
      searchTermEn: row.search_term_en, isCardio: row.is_cardio, currentWeight: Number(row.current_weight),
      targetSets: row.target_sets, repMin: row.rep_min, repMax: row.rep_max, increment: Number(row.increment),
      note: row.note, orderIndex: row.order_index, nextSuggestion: row.next_suggestion as ProgressionSuggestion | null,
      history: sessionsByExercise[row.id] ?? [],
    };
    (exercisesByRoutine[row.routine_id] ??= []).push(exercise);
  }

  return (routineRows ?? []).map((r: any) => ({
    id: r.id, name: r.name, orderIndex: r.order_index, exercises: exercisesByRoutine[r.id] ?? [],
  }));
}

export const getBoraData = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const [profileResult, messagesResult, routines] = await Promise.all([
      context.supabase.from("profiles").select("*").eq("user_id", context.userId).maybeSingle(),
      context.supabase.from("chat_messages").select("id, role, content, message_parts, created_at").eq("user_id", context.userId).order("created_at", { ascending: true }).limit(80),
      loadRoutines(context.supabase, context.userId),
    ]);
    if (profileResult.error) throw new Error(profileResult.error.message);
    if (messagesResult.error) throw new Error(messagesResult.error.message);

    return {
      profile: profileResult.data,
      routines,
      messages: (messagesResult.data ?? []).map((message: any) => ({
        id: message.id,
        role: message.role === "user" ? "user" as const : "assistant" as const,
        parts: [{ type: "text" as const, text: message.content }],
      })),
    };
  });

export const saveProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => profileSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("profiles").upsert({
      user_id: context.userId,
      display_name: data.displayName,
      objective: data.objective,
      experience: data.experience,
      gender: data.gender,
      phase: data.phase,
      plan_source: data.planSource,
      body_focus: data.bodyFocus,
      training_days: data.trainingDays,
      current_weight: data.currentWeight,
      onboarding_complete: true,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const createRoutine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ name: z.string().min(1) }).parse(input))
  .handler(async ({ data, context }) => {
    const { count } = await context.supabase.from("routines").select("id", { count: "exact", head: true }).eq("user_id", context.userId);
    const { data: created, error } = await context.supabase
      .from("routines").insert({ user_id: context.userId, name: data.name, order_index: count ?? 0 }).select().single();
    if (error) throw new Error(error.message);
    return created;
  });

export const renameRoutine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ routineId: z.string(), name: z.string().min(1) }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("routines").update({ name: data.name }).eq("id", data.routineId).eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteRoutine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ routineId: z.string() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("routines").delete().eq("id", data.routineId).eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const reorderRoutineExercises = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ routineId: z.string(), orderedExerciseIds: z.array(z.string()) }).parse(input))
  .handler(async ({ data, context }) => {
    const results = await Promise.all(
      data.orderedExerciseIds.map((id, index) =>
        context.supabase.from("routine_exercises").update({ order_index: index }).eq("id", id).eq("routine_id", data.routineId).eq("user_id", context.userId)
      )
    );
    const failed = results.find((result: { error: { message: string } | null }) => result.error);
    if (failed?.error) throw new Error(failed.error.message);
    return { ok: true };
  });

const addExerciseSchema = z.object({
  routineId: z.string(), name: z.string(), muscleGroup: z.string(), searchTermEn: z.string().nullable().optional(),
  isCardio: z.boolean().default(false), startingWeight: z.number(), targetSets: z.number(),
  repMin: z.number(), repMax: z.number(), increment: z.number(),
});

export const addExerciseToRoutine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => addExerciseSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { count } = await context.supabase.from("routine_exercises").select("id", { count: "exact", head: true }).eq("routine_id", data.routineId);
    const { data: created, error } = await context.supabase.from("routine_exercises").insert({
      routine_id: data.routineId, user_id: context.userId, name: data.name, muscle_group: data.muscleGroup,
      search_term_en: data.searchTermEn ?? null, is_cardio: data.isCardio, current_weight: data.startingWeight,
      target_sets: data.targetSets, rep_min: data.repMin, rep_max: data.repMax, increment: data.increment,
      order_index: count ?? 0,
    }).select().single();
    if (error) throw new Error(error.message);
    return created;
  });

export const removeExerciseFromRoutine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ exerciseId: z.string() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("routine_exercises").delete().eq("id", data.exerciseId).eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const updateExerciseNote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ exerciseId: z.string(), note: z.string() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("routine_exercises").update({ note: data.note }).eq("id", data.exerciseId).eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/**
 * Registra uma sessão de um exercício e recalcula a sugestão de progressão
 * pelo fallback determinístico (dupla progressão conservadora). Isso roda
 * SEMPRE, mesmo sem IA — o Assistente pode depois refinar essa sugestão via
 * chat, mas o app nunca fica sem uma sugestão.
 */
export const logExerciseSession = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ exerciseId: z.string(), sets: z.array(setEntrySchema).min(1), skipProgression: z.boolean().optional() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: exerciseRow, error: exerciseError } = await context.supabase
      .from("routine_exercises").select("*").eq("id", data.exerciseId).eq("user_id", context.userId).single();
    if (exerciseError || !exerciseRow) throw new Error(exerciseError?.message ?? "exercício não encontrado");

    const { error: insertError } = await context.supabase.from("exercise_sessions").insert({
      routine_exercise_id: data.exerciseId, user_id: context.userId,
      sets: data.sets as never,
    });
    if (insertError) throw new Error(insertError.message);
    // dia adaptado com intensidade reduzida: registra, mas não altera a progressão
    if (data.skipProgression) return { suggestion: exerciseRow.next_suggestion as ProgressionSuggestion | null };

    const { data: historyRows, error: historyError } = await context.supabase
      .from("exercise_sessions").select("*").eq("routine_exercise_id", data.exerciseId).order("performed_at", { ascending: true }).limit(HISTORY_LIMIT_PER_EXERCISE);
    if (historyError) throw new Error(historyError.message);
    const history: ExerciseSession[] = (historyRows ?? []).map((row: any) => ({ id: row.id, performedAt: row.performed_at, sets: row.sets as SetEntry[] }));

    const suggestion = fallbackProgression(
      {
        isCardio: exerciseRow.is_cardio, currentWeight: Number(exerciseRow.current_weight),
        repMin: exerciseRow.rep_min, repMax: exerciseRow.rep_max, increment: Number(exerciseRow.increment),
        history,
      },
      data.sets
    );

    const { error: updateError } = await context.supabase.from("routine_exercises").update({
      current_weight: suggestion.weight, next_suggestion: suggestion as never,
    }).eq("id", data.exerciseId).eq("user_id", context.userId);
    if (updateError) throw new Error(updateError.message);

    return { suggestion };
  });
