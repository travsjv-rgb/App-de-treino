import type { ExerciseSession, ProgressionSuggestion, RoutineExercise, SetEntry } from "./bora-types";

export function round5(n: number): number {
  return Math.round(n * 2) / 2;
}

/** Estagnação: mesma carga de trabalho (peso da 1ª série) nas últimas 3 sessões registradas. */
export function isStagnant(exercise: Pick<RoutineExercise, "history">): boolean {
  if (exercise.history.length < 3) return false;
  const lastThree = exercise.history.slice(-3);
  const weights = lastThree.map((h) => (h.sets[0] ? h.sets[0].weight : 0));
  const first = weights[0] ?? 0;
  return weights.every((w) => w === first) && first > 0;
}

/**
 * Dupla progressão conservadora — o coração da progressão de carga do BORA.
 * NUNCA decide subir carga com base numa sessão só. Só sobe (incremento pequeno,
 * "microtonelagem") quando as ÚLTIMAS 2 sessões seguidas bateram o teto da faixa
 * de reps com folga (RIR alto). Enquanto isso não acontece, orienta um alvo
 * concreto de reps pra próxima sessão, mantendo a carga.
 */
export function fallbackProgression(
  exercise: Pick<RoutineExercise, "isCardio" | "currentWeight" | "repMin" | "repMax" | "increment" | "history">,
  currentSets: SetEntry[]
): ProgressionSuggestion {
  const cardio = exercise.isCardio;
  const historyIncludingNow: ExerciseSession[] = [
    ...exercise.history.slice(0, -1),
    { id: "current", performedAt: new Date().toISOString(), sets: currentSets },
  ].slice(-3);
  const relevantSessions = historyIncludingNow.length ? historyIncludingNow : [{ id: "current", performedAt: new Date().toISOString(), sets: currentSets }];
  const lastTwo = relevantSessions.slice(-2);
  const recentFailure = relevantSessions.some((h) => h.sets.some((s) => s.rir <= 0 && s.reps < exercise.repMin));
  const stagnant = isStagnant(exercise);
  const bestRepsLast = Math.max(...currentSets.map((s) => s.reps));
  const avgRirLast = currentSets.reduce((a, s) => a + s.rir, 0) / currentSets.length;

  const confirmedCeiling =
    lastTwo.length === 2 &&
    lastTwo.every(
      (h) => h.sets.every((s) => s.reps >= exercise.repMax) && h.sets.reduce((a, s) => a + s.rir, 0) / h.sets.length >= 2
    );

  if (recentFailure) {
    return {
      weight: round5(exercise.currentWeight),
      repsTarget: String(Math.max(exercise.repMin, bestRepsLast)),
      reason: "teve uma série abaixo da faixa mínima recentemente — mantenha a mesma carga e foque em consolidar essas reps antes de qualquer progressão.",
    };
  }
  if (confirmedCeiling) {
    return {
      weight: round5(exercise.currentWeight + exercise.increment),
      repsTarget: `${exercise.repMin}-${exercise.repMax}`,
      reason: cardio
        ? "confirmou esforço confortável em 2 sessões seguidas — pequeno aumento de duração/intensidade."
        : "confirmou o teto da faixa de reps com folga em 2 sessões seguidas — pequena progressão de carga (microtonelagem).",
    };
  }
  if (stagnant) {
    return {
      weight: round5(exercise.currentWeight),
      repsTarget: `${exercise.repMin}-${exercise.repMax}`,
      reason: "carga estável há 3 sessões sem confirmar o teto de reps — considere trocar a variação ou revisar volume/recuperação.",
    };
  }
  const nextRepsTarget = Math.min(exercise.repMax, bestRepsLast + (avgRirLast >= 2 ? 1 : 0));
  return {
    weight: round5(exercise.currentWeight),
    repsTarget: String(nextRepsTarget),
    reason: cardio
      ? "continue no mesmo ritmo e vá aumentando aos poucos."
      : `mesma carga — tente atingir ${nextRepsTarget} reps na próxima sessão antes de pensar em subir o peso.`,
  };
}

/**
 * Persona científica compartilhada — prefixar em TODO prompt de IA do app
 * (sugestão de progressão, criação de plano, adaptação de treino, chat do Assistente).
 * Isso é o que fazia o app original ser "inteligente de verdade" e não um gerador
 * genérico de fichas — não decidir progressão, montar treino, ou responder perguntas
 * de treino sem isso no prompt.
 */
export const AI_PERSONA = `Você é uma IA especialista em treinamento físico, musculação e hipertrofia, com prescrição baseada em evidências (meta-análises, revisões sistemáticas, position stands — nunca invente estudos).

PRINCÍPIOS: considere objetivo, nível de treino, volume e frequência semanal, proximidade da falha (RIR), seleção de exercícios, padrões de movimento, fadiga local/sistêmica, recuperação e aderência da pessoa. Priorize o que gera mais resultado com menor custo de fadiga e complexidade.

NUNCA use regras dogmáticas: nenhum exercício é "obrigatório" ou "inútil", não existe faixa de reps fixa para hipertrofia, "composto sempre primeiro" não é regra absoluta, 2x ou 3x por semana por músculo é ferramenta de distribuir volume, não lei fisiológica — o que mais importa é o volume semanal total bem executado.

BIOMECÂNICA (use isso pra montar/ajustar treinos com critério):
- Costas = adução e extensão de ombro + retração escapular. Puxada alta (cotovelos descem até o quadril) e remada fechada/neutra (trajetória sagital) enfatizam mais a adução; remada aberta ou Kelso shrug (encolhimento horizontal) enfatiza mais a retração escapular.
- Bíceps = só flexão de cotovelo.
- Tríceps = só extensão de cotovelo.
- Abdômen = flexão de tronco.
Ajuste a ênfase conforme o foco da pessoa, sem forçar todos os padrões em todo programa.

PROGRESSÃO: dupla progressão como padrão — mantenha a carga até confirmar o teto da faixa de reps com folga (RIR alto) por 2 sessões seguidas, só então suba a carga (incremento pequeno, "microtonelagem"). Nunca recomende sacrificar técnica por um número. Não decida progressão de carga com base numa sessão isolada.

ADAPTAÇÃO POR FADIGA: quando o usuário relatar cansaço/sono ruim/pouco tempo e for preciso reduzir o treino do dia, prefira remover ou substituir um isolador redundante por uma alternativa mais completa baseada em padrão de movimento (ex: se já tem agachamento no treino, cortar cadeira extensora antes de cortar séries de outros exercícios; priorizar um hinge como stiff/RDL em vez de mesa flexora) em vez de simplesmente cortar séries de tudo igualmente.

Seja direto e conciso nas respostas — isso aparece numa tela de celular.`;
