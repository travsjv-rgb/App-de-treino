export type SetEntry = {
  weight: number;
  reps: number;
  rir: number; // 0 (falha) a 4+ (muito fácil)
};

export type ExerciseSession = {
  id: string;
  performedAt: string; // ISO date
  sets: SetEntry[];
};

export type ProgressionSuggestion = {
  weight: number;
  repsTarget: string; // ex: "9" (alvo concreto) ou "8-12" (faixa, quando confirma progressão de carga)
  reason: string;
};

export type RoutineExercise = {
  id: string;
  routineId: string;
  name: string;
  muscleGroup: string;
  searchTermEn: string | null;
  isCardio: boolean;
  currentWeight: number;
  targetSets: number;
  repMin: number;
  repMax: number;
  increment: number;
  note: string | null;
  orderIndex: number;
  nextSuggestion: ProgressionSuggestion | null;
  history: ExerciseSession[]; // carregado à parte, não fica na tabela routine_exercises
};

export type Routine = {
  id: string;
  name: string;
  orderIndex: number;
  exercises: RoutineExercise[];
};

export type Gender = "masculino" | "feminino" | "prefiro_nao_dizer";
export type Experience = "iniciante" | "intermediario" | "avancado";
export type Phase = "cutting" | "manutencao" | "bulk";
export type PlanSource = "manual" | "ai";
export type BodyFocus = "superior" | "inferior" | "geral";
export type Objective = "estetica" | "forca" | "emagrecimento" | "saude";

export type Profile = {
  displayName: string;
  objective: Objective | string;
  experience: Experience | string;
  gender: Gender | null;
  phase: Phase;
  planSource: PlanSource;
  bodyFocus: BodyFocus;
  trainingDays: number;
  currentWeight: number | null;
  onboardingComplete: boolean;
};

// mantido pro fluxo antigo do Builder por foco (tela de "montar com IA")
export type FocusChoice = "superiores" | "inferiores" | "corpo_inteiro";
