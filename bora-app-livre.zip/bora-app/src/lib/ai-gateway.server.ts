import { createGoogleGenerativeAI } from "@ai-sdk/google";

/**
 * Provedor de IA do BORA — Google Gemini (API gratuita, sem cartão).
 * Usa a chave do próprio projeto, guardada como variável de
 * ambiente do servidor (GEMINI_API_KEY) — nunca fica exposta no navegador.
 *
 * Se um dia quiser trocar de provedor de novo, essa é a única função que
 * precisa mudar — o resto do app (chat.ts, etc.) só chama createBoraAI(key).
 */
export function createBoraAI(apiKey: string) {
  const google = createGoogleGenerativeAI({ apiKey });
  return {
    // "gemini-3.6-flash" é o modelo padrão atual: rápido e com camada gratuita generosa.
    model: google("gemini-3.6-flash"),
  };
}
