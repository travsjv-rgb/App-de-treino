import { useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Check, ChevronDown, GripVertical, MessageCircle, Minus, Pencil, Play, Plus, Share2, Sparkles, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EXERCISE_CATALOG } from "@/lib/bora-exercises";
import { addExerciseToRoutine, createRoutine, logExerciseSession, removeExerciseFromRoutine, renameRoutine, reorderRoutineExercises, updateExerciseNote } from "@/lib/bora.functions";
import type { Routine, RoutineExercise } from "@/lib/bora-types";

type DraftSet = { weight: number; reps: number; rir: number; done: boolean };
type DraftExercise = { exerciseId: string; name: string; originalName: string; muscleGroup: string; isCardio: boolean; note: string; sets: DraftSet[]; skipped: boolean; substituted: boolean; reduced: boolean; target: string };
type Draft = { routineId: string; routineName: string; startedAt: string; exercises: DraftExercise[]; adaptations: string[] };
export type ChatSeed = { prompt: string; context: string };

const draftKey = (routineId: string) => `bora-session-${routineId}`;
const round = (n: number) => Math.round(n * 2) / 2;

function buildDraft(routine: Routine): Draft {
  return {
    routineId: routine.id, routineName: routine.name, startedAt: new Date().toISOString(), adaptations: [],
    exercises: routine.exercises.map((ex) => {
      const last = ex.history.at(-1);
      const weight = ex.nextSuggestion?.weight ?? ex.currentWeight;
      const reps = Number.parseInt(ex.nextSuggestion?.repsTarget ?? "", 10) || ex.repMin;
      const sets = Array.from({ length: ex.targetSets }, (_, i) => {
        const prev = last?.sets[i];
        return ex.isCardio ? { weight: prev?.weight ?? 0, reps: prev?.reps ?? 10, rir: 2, done: false } : { weight, reps, rir: 2, done: false };
      });
      return { exerciseId: ex.id, name: ex.name, originalName: ex.name, muscleGroup: ex.muscleGroup, isCardio: ex.isCardio, note: ex.note ?? "", sets, skipped: false, substituted: false, reduced: false,
        target: ex.isCardio ? "Cardio" : `${ex.targetSets} × ${ex.nextSuggestion?.repsTarget ?? `${ex.repMin}-${ex.repMax}`} · ${weight || "PC"}${weight ? " kg" : ""}` };
    }),
  };
}

export function describeDraft(draft: Draft) {
  return `Treino em andamento: ${draft.routineName}. Adaptações aplicadas: ${draft.adaptations.join(", ") || "nenhuma"}. Exercícios: ${draft.exercises.map((e) => `${e.name}${e.skipped ? " (removido hoje)" : ""}${e.substituted ? ` (substitui ${e.originalName})` : ""} — ${e.sets.filter((s) => s.done).length}/${e.sets.length} séries feitas`).join("; ")}.`;
}

export function WorkoutScreen({ routines, openBuilder, onChanged, openChat }: { routines: Routine[]; openBuilder: () => void; onChanged: () => Promise<unknown>; openChat: (seed: ChatSeed) => void }) {
  const [selectedId, setSelectedId] = useState(routines[0]?.id);
  const routine = routines.find((r) => r.id === selectedId) ?? routines[0];
  const [draft, setDraft] = useState<Draft | null>(null);
  const [editing, setEditing] = useState(false);
  const create = useServerFn(createRoutine);

  useEffect(() => {
    if (!routine) return;
    const saved = localStorage.getItem(draftKey(routine.id));
    setDraft(saved ? JSON.parse(saved) as Draft : null);
  }, [routine?.id]);
  useEffect(() => { if (draft) localStorage.setItem(draftKey(draft.routineId), JSON.stringify(draft)); }, [draft]);

  const newRoutine = async () => {
    const name = window.prompt("Nome da nova rotina", `Treino ${String.fromCharCode(65 + routines.length)}`)?.trim();
    if (!name) return;
    const created = await create({ data: { name } });
    await onChanged(); setSelectedId(created.id); setEditing(true);
  };

  if (!routine) return <div className="grid min-h-[60vh] place-items-center text-center"><div><h1 className="text-2xl font-bold">Nenhum treino montado</h1><p className="mt-2 text-sm text-muted-foreground">Monte com a IA ou crie sua própria rotina.</p><div className="mt-6 flex justify-center gap-2"><Button onClick={openBuilder}><Sparkles/>Montar com IA</Button><Button variant="outline" onClick={newRoutine}><Plus/>Criar rotina</Button></div></div></div>;

  if (draft) return <SessionView draft={draft} setDraft={setDraft} routine={routine} onFinish={async () => { localStorage.removeItem(draftKey(draft.routineId)); setDraft(null); await onChanged(); }} openChat={openChat}/>;

  return <div>
    <span className="eyebrow">MINHAS ROTINAS</span>
    <div className="mt-4 flex gap-2 overflow-x-auto pb-2">{routines.map((r) => <Button key={r.id} size="sm" variant={r.id === routine.id ? "default" : "outline"} onClick={() => { setSelectedId(r.id); setEditing(false); }}>{r.name}</Button>)}<Button size="sm" variant="ghost" onClick={newRoutine}><Plus/>Nova</Button></div>
    <RoutineHeader routine={routine} onChanged={onChanged} editing={editing} setEditing={setEditing}/>
    {!editing && <Button className="mt-5 h-12 w-full font-bold" disabled={!routine.exercises.length} onClick={() => setDraft(buildDraft(routine))}><Play/>Iniciar treino</Button>}
    <ExerciseList routine={routine} editing={editing} onChanged={onChanged}/>
    {editing && <AddExercise routineId={routine.id} onChanged={onChanged}/>}
    <Button variant="outline" className="mt-6 h-11 w-full" onClick={openBuilder}><Sparkles/>Ajustar com a IA</Button>
  </div>;
}

function RoutineHeader({ routine, onChanged, editing, setEditing }: { routine: Routine; onChanged: () => Promise<unknown>; editing: boolean; setEditing: (v: boolean) => void }) {
  const rename = useServerFn(renameRoutine);
  const doRename = async () => {
    const name = window.prompt("Renomear rotina", routine.name)?.trim();
    if (!name || name === routine.name) return;
    await rename({ data: { routineId: routine.id, name } }); await onChanged(); toast.success("Rotina renomeada");
  };
  return <div className="mt-3 flex items-start justify-between gap-3"><div className="min-w-0"><h1 className="truncate text-3xl font-bold">{routine.name}</h1><p className="mt-1 text-xs text-muted-foreground">{routine.exercises.length} exercícios</p></div><div className="flex gap-1"><Button size="icon" variant="ghost" aria-label="Renomear rotina" onClick={doRename}><Pencil/></Button><Button size="sm" variant={editing ? "default" : "outline"} onClick={() => setEditing(!editing)}>{editing ? <><Check/>Pronto</> : "Editar"}</Button></div></div>;
}

function ExerciseList({ routine, editing, onChanged }: { routine: Routine; editing: boolean; onChanged: () => Promise<unknown> }) {
  const [order, setOrder] = useState<RoutineExercise[]>(routine.exercises);
  const [dragId, setDragId] = useState<string | null>(null);
  const reorder = useServerFn(reorderRoutineExercises);
  const remove = useServerFn(removeExerciseFromRoutine);
  useEffect(() => { setOrder(routine.exercises); }, [routine]);

  const onDown = (e: ReactPointerEvent, id: string) => { e.preventDefault(); (e.target as HTMLElement).setPointerCapture(e.pointerId); setDragId(id); };
  const onMove = (e: ReactPointerEvent) => {
    if (!dragId) return;
    const over = document.elementFromPoint(e.clientX, e.clientY)?.closest<HTMLElement>("[data-ex-id]")?.dataset["exId"];
    if (!over || over === dragId) return;
    setOrder((list) => { const from = list.findIndex((x) => x.id === dragId); const to = list.findIndex((x) => x.id === over); const next = [...list]; const [item] = next.splice(from, 1); if (item) next.splice(to, 0, item); return next; });
  };
  const onUp = async () => {
    if (!dragId) return; setDragId(null);
    if (order.map((x) => x.id).join() === routine.exercises.map((x) => x.id).join()) return;
    await reorder({ data: { routineId: routine.id, orderedExerciseIds: order.map((x) => x.id) } }); await onChanged();
  };

  return <div className="mt-5 divide-y divide-border border-y border-border">{order.map((ex, i) => <div key={ex.id} data-ex-id={ex.id} className={`flex items-center gap-3 py-3.5 transition-colors ${dragId === ex.id ? "bg-secondary" : ""}`}>
    <button aria-label={`Arrastar ${ex.name}`} className="touch-none cursor-grab p-1 text-muted-foreground" onPointerDown={(e) => onDown(e, ex.id)} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}><GripVertical className="size-5"/></button>
    <span className="grid size-8 shrink-0 place-items-center rounded-sm bg-secondary text-xs font-bold text-primary">{String(i + 1).padStart(2, "0")}</span>
    <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{ex.name}</p><p className="text-xs text-muted-foreground">{ex.muscleGroup}{ex.note ? ` · ${ex.note}` : ""}</p></div>
    {editing ? <Button size="icon" variant="ghost" aria-label={`Remover ${ex.name}`} onClick={async () => { await remove({ data: { exerciseId: ex.id } }); await onChanged(); }}><Trash2 className="text-destructive"/></Button>
      : <div className="text-right text-xs"><b className="text-sm">{ex.isCardio ? "Cardio" : `${ex.targetSets} × ${ex.repMin}-${ex.repMax}`}</b><p className="text-muted-foreground">{ex.currentWeight ? `${ex.currentWeight} kg` : "peso corporal"}</p></div>}
  </div>)}</div>;
}

function AddExercise({ routineId, onChanged }: { routineId: string; onChanged: () => Promise<unknown> }) {
  const [q, setQ] = useState("");
  const add = useServerFn(addExerciseToRoutine);
  const results = useMemo(() => q.trim().length < 2 ? [] : EXERCISE_CATALOG.filter((e) => `${e.name} ${e.muscleGroup}`.toLowerCase().includes(q.toLowerCase())).slice(0, 6), [q]);
  const pick = async (entry: (typeof EXERCISE_CATALOG)[number], variation?: string) => {
    const isCardio = entry.muscleGroup.toLowerCase().includes("cardio");
    await add({ data: { routineId, name: variation ? `${entry.name} (${variation})` : entry.name, muscleGroup: entry.muscleGroup, searchTermEn: entry.searchTermEn, isCardio, startingWeight: 0, targetSets: isCardio ? 1 : 3, repMin: 8, repMax: 12, increment: 2.5 } });
    setQ(""); await onChanged(); toast.success("Exercício adicionado");
  };
  return <div className="mt-4 rounded-lg border border-border bg-card p-3"><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar exercício para adicionar..."/>
    <div className="mt-2 space-y-2">{results.map((entry) => <div key={entry.name} className="rounded-md border border-border p-2"><p className="text-sm font-semibold">{entry.name} <span className="text-xs font-normal text-muted-foreground">· {entry.muscleGroup}</span></p><div className="mt-2 flex flex-wrap gap-1.5">{entry.variations.map((v) => <Button key={v} size="sm" variant="outline" className="h-7 text-xs" onClick={() => pick(entry, v)}>{v}</Button>)}</div></div>)}</div></div>;
}

const ADAPTATIONS = ["Pouco tempo", "Equipamento ocupado", "Desconforto", "Reduzir intensidade"] as const;

function SessionView({ draft, setDraft, routine, onFinish, openChat }: { draft: Draft; setDraft: (d: Draft | null) => void; routine: Routine; onFinish: () => Promise<void>; openChat: (seed: ChatSeed) => void }) {
  const [open, setOpen] = useState(0);
  const [saving, setSaving] = useState(false);
  const log = useServerFn(logExerciseSession);
  const saveNote = useServerFn(updateExerciseNote);
  const noteTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  const update = (index: number, fn: (e: DraftExercise) => DraftExercise) => setDraft({ ...draft, exercises: draft.exercises.map((e, i) => i === index ? fn(e) : e) });
  const doneSets = draft.exercises.reduce((n, e) => n + (e.skipped ? 0 : e.sets.filter((s) => s.done).length), 0);
  const totalSets = draft.exercises.reduce((n, e) => n + (e.skipped ? 0 : e.sets.length), 0);

  const adapt = (kind: (typeof ADAPTATIONS)[number]) => {
    const target = draft.exercises[open];
    let exercises = draft.exercises;
    if (kind === "Pouco tempo") {
      let kept = 0;
      exercises = exercises.map((e) => { if (e.skipped) return e; kept++; return kept > 4 ? { ...e, skipped: true } : { ...e, sets: e.sets.slice(0, Math.max(2, e.sets.length - 1)) }; });
    } else if (kind === "Equipamento ocupado" && target) {
      const alt = EXERCISE_CATALOG.find((c) => c.muscleGroup === target.muscleGroup && !target.originalName.startsWith(c.name) && !draft.exercises.some((d) => d.name.startsWith(c.name)));
      if (!alt) { toast("Sem variação equivalente no catálogo — peça ajuda à assistente."); return; }
      exercises = exercises.map((e, i) => i === open ? { ...e, name: `${alt.name} (${alt.variations[0] ?? ""})`, substituted: true } : e);
      toast(`${target.originalName} trocado por ${alt.name}`);
    } else if (kind === "Desconforto" && target) {
      exercises = exercises.map((e, i) => i === open ? { ...e, skipped: true } : e);
      setOpen(Math.min(open + 1, exercises.length - 1));
    } else if (kind === "Reduzir intensidade") {
      exercises = exercises.map((e) => e.isCardio ? e : { ...e, reduced: true, sets: e.sets.slice(0, Math.max(2, e.sets.length - 1)).map((s) => ({ ...s, weight: round(s.weight * 0.85) })) });
    }
    setDraft({ ...draft, exercises, adaptations: [...new Set([...draft.adaptations, kind])] });
  };

  const finish = async () => {
    setSaving(true);
    try {
      let logged = 0;
      for (const e of draft.exercises) {
        if (e.skipped || e.substituted) continue; // não mexe na progressão de um exercício que não foi feito
        const sets = e.sets.filter((s) => s.done).map(({ weight, reps, rir }) => ({ weight, reps, rir }));
        if (!sets.length) continue;
        await log({ data: { exerciseId: e.exerciseId, sets, skipProgression: e.reduced } });
        logged++;
      }
      toast.success(logged ? `Treino concluído! ${logged} exercícios registrados.` : "Treino encerrado sem séries marcadas.");
      await onFinish();
    } catch (err) { toast.error(err instanceof Error ? err.message : "Não foi possível salvar o treino"); }
    finally { setSaving(false); }
  };

  const share = async () => {
    const text = `BORΛ · ${draft.routineName}\n${draft.exercises.filter((e) => !e.skipped).map((e) => `${e.name}: ${e.sets.filter((s) => s.done).map((s) => e.isCardio ? `${s.reps}min` : `${s.weight}kg×${s.reps}`).join(", ") || "—"}`).join("\n")}`;
    if (navigator.share) await navigator.share({ text }).catch(() => undefined); else { await navigator.clipboard.writeText(text); toast("Resumo copiado"); }
  };

  return <div>
    <div className="flex items-center justify-between"><span className="eyebrow">TREINO EM ANDAMENTO</span><Button size="sm" variant="ghost" onClick={() => { if (window.confirm("Descartar este treino?")) { localStorage.removeItem(draftKey(draft.routineId)); setDraft(null); } }}><X/>Descartar</Button></div>
    <h1 className="mt-2 text-3xl font-bold">{draft.routineName}</h1>
    <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-secondary"><div className="h-full bg-primary transition-all" style={{ width: `${totalSets ? (doneSets / totalSets) * 100 : 0}%` }}/></div>
    <p className="mt-1.5 text-xs text-muted-foreground">{doneSets}/{totalSets} séries concluídas</p>

    <div className="mt-5"><p className="text-xs font-semibold text-muted-foreground">Adaptar treino de hoje</p><div className="mt-2 flex flex-wrap gap-2">{ADAPTATIONS.map((a) => <Button key={a} size="sm" variant={draft.adaptations.includes(a) ? "default" : "outline"} className="h-8 text-xs" onClick={() => adapt(a)}>{a}</Button>)}<Button size="sm" variant="ghost" className="h-8 text-xs" onClick={() => openChat({ prompt: `Preciso adaptar meu treino de hoje (${draft.routineName}). ${draft.adaptations.length ? `Já apliquei: ${draft.adaptations.join(", ")}.` : ""} O que você sugere?`, context: describeDraft(draft) })}><MessageCircle/>Explicar à assistente</Button></div></div>

    <div className="mt-5 space-y-3">{draft.exercises.map((e, i) => <section key={e.exerciseId} className={`rounded-lg border bg-card ${i === open ? "border-primary/60" : "border-border"} ${e.skipped ? "opacity-50" : ""}`}>
      <button className="flex w-full items-center gap-3 p-4 text-left" onClick={() => setOpen(i === open ? -1 : i)}>
        <span className={`grid size-8 shrink-0 place-items-center rounded-sm text-xs font-bold ${e.sets.every((s) => s.done) && !e.skipped ? "bg-primary text-primary-foreground" : "bg-secondary text-primary"}`}>{e.sets.every((s) => s.done) && !e.skipped ? <Check className="size-4"/> : String(i + 1).padStart(2, "0")}</span>
        <span className="min-w-0 flex-1"><b className="block truncate text-sm">{e.name}</b><span className="text-xs text-muted-foreground">{e.skipped ? "Removido hoje" : e.substituted ? `Substitui ${e.originalName}` : e.target}{e.reduced ? " · intensidade reduzida" : ""}</span></span>
        <ChevronDown className={`size-4 transition-transform ${i === open ? "rotate-180" : ""}`}/>
      </button>
      {i === open && !e.skipped && <div className="border-t border-border p-4">
        <div className="grid grid-cols-[1.5rem_1fr_1fr_1fr_2.25rem] gap-2 text-[10px] font-semibold uppercase text-muted-foreground"><span>#</span><span>{e.isCardio ? "Vel./nível" : "Kg"}</span><span>{e.isCardio ? "Min" : "Reps"}</span><span>{e.isCardio ? "" : "RIR"}</span><span/></div>
        {e.sets.map((s, si) => <div key={si} className={`mt-2 grid grid-cols-[1.5rem_1fr_1fr_1fr_2.25rem] items-center gap-2 ${s.done ? "opacity-70" : ""}`}>
          <span className="text-xs font-bold text-muted-foreground">{si + 1}</span>
          <Input type="number" inputMode="decimal" className="h-9 px-2 text-center" value={s.weight} onChange={(ev) => update(i, (x) => ({ ...x, sets: x.sets.map((y, yi) => yi === si ? { ...y, weight: Number(ev.target.value) } : y) }))}/>
          <Input type="number" inputMode="numeric" className="h-9 px-2 text-center" value={s.reps} onChange={(ev) => update(i, (x) => ({ ...x, sets: x.sets.map((y, yi) => yi === si ? { ...y, reps: Number(ev.target.value) } : y) }))}/>
          {e.isCardio ? <span/> : <select aria-label="RIR" className="h-9 rounded-md border border-input bg-background px-1 text-center text-sm" value={s.rir} onChange={(ev) => update(i, (x) => ({ ...x, sets: x.sets.map((y, yi) => yi === si ? { ...y, rir: Number(ev.target.value) } : y) }))}>{[0, 1, 2, 3, 4].map((r) => <option key={r} value={r}>{r === 4 ? "4+" : r}</option>)}</select>}
          <Button size="icon" variant={s.done ? "default" : "outline"} className="size-9" aria-label="Marcar série" onClick={() => update(i, (x) => ({ ...x, sets: x.sets.map((y, yi) => yi === si ? { ...y, done: !y.done } : y) }))}><Check/></Button>
        </div>)}
        <div className="mt-3 flex gap-2"><Button size="sm" variant="outline" onClick={() => update(i, (x) => ({ ...x, sets: [...x.sets, { ...(x.sets.at(-1) ?? { weight: 0, reps: 10, rir: 2 }), done: false }] }))}><Plus/>Série</Button><Button size="sm" variant="ghost" disabled={e.sets.length <= 1} onClick={() => update(i, (x) => ({ ...x, sets: x.sets.slice(0, -1) }))}><Minus/>Série</Button></div>
        <textarea className="mt-3 min-h-16 w-full rounded-md border border-input bg-background p-2 text-sm" placeholder="Nota do exercício (ajuste do banco, pegada...)" value={e.note} onChange={(ev) => { const note = ev.target.value; update(i, (x) => ({ ...x, note })); clearTimeout(noteTimers.current[e.exerciseId]); noteTimers.current[e.exerciseId] = setTimeout(() => void saveNote({ data: { exerciseId: e.exerciseId, note } }), 800); }}/>
      </div>}
    </section>)}</div>

    <div className="mt-6 grid grid-cols-[1fr_auto] gap-2"><Button className="h-12 font-bold" disabled={saving} onClick={finish}>{saving ? "Salvando..." : "Concluir treino"}<Check/></Button><Button variant="outline" className="h-12" aria-label="Compartilhar treino" onClick={share}><Share2/></Button></div>
    {routine.exercises.length !== draft.exercises.length && <p className="mt-2 text-xs text-muted-foreground">A rotina mudou desde que você iniciou este treino.</p>}
  </div>;
}
