# BORA

App de treino com IA: monte treinos, registre séries e acompanhe sua evolução.

**Stack:** TanStack Start · React 19 · TypeScript · Tailwind CSS 4 · Supabase · Google Gemini

## Rodando local

```sh
cp .env.example .env   # preencha as chaves do Supabase e a GEMINI_API_KEY
npm install            # ou: bun install
npm run dev
```

## Variáveis de ambiente

Veja `.env.example`. Opcional: `CRON_SECRET` protege endpoints chamados por cron.

## Login com Google

Usa `supabase.auth.signInWithOAuth`. Ative o provedor Google em
Supabase → Authentication → Providers e adicione a URL do app em Redirect URLs.

## Banco

Migrações em `supabase/migrations` (aplique com a CLI do Supabase: `supabase db push`).

## Build

```sh
npm run build
```
Deploy na Netlify: o `netlify.toml` já define build (`vite build`) e pasta de publicação (`dist/client`).
