import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";
import netlify from "@netlify/vite-plugin-tanstack-start";

// Config própria do BORA.
// Variáveis VITE_* são injetadas pelo próprio Vite a partir do .env.
// O alias "@" -> src vem do tsconfig.json (via vite-tsconfig-paths).
export default defineConfig(() => ({
  plugins: [
    tsConfigPaths(),
    tanstackStart({
      // Usa src/server.ts (wrapper de erro de SSR) como entrada do servidor.
      server: { entry: "server" },
    }),
    viteReact(),
    tailwindcss(),
    // Adaptador da Netlify (SSR, rotas de API e server functions viram Netlify Functions).
    netlify(),
  ],
  resolve: {
    dedupe: ["react", "react-dom", "@tanstack/react-router", "@tanstack/react-start"],
  },
}));
