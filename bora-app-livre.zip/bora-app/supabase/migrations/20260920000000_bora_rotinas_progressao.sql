-- BORA: migração pra suportar rotinas múltiplas, RIR por série, histórico de sessões,
-- notas por exercício e o novo perfil (gênero, fase, foco corporal).
-- Substitui o modelo antigo de "um plano ativo só" (workout_plans) por rotinas de verdade.

-- 1) Perfil: campos novos usados pelo onboarding e pela IA
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS gender text,
  ADD COLUMN IF NOT EXISTS phase text NOT NULL DEFAULT 'manutencao',
  ADD COLUMN IF NOT EXISTS plan_source text NOT NULL DEFAULT 'manual',
  ADD COLUMN IF NOT EXISTS body_focus text NOT NULL DEFAULT 'geral';
-- phase: 'cutting' | 'manutencao' | 'bulk'
-- plan_source: 'manual' | 'ai'  (se o usuário monta sozinho ou deixa a IA montar)
-- body_focus: 'superior' | 'inferior' | 'geral'

-- 2) Rotinas — várias por usuário, como no Hevy
CREATE TABLE public.routines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  name text NOT NULL DEFAULT 'Meu treino',
  order_index integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.routines TO authenticated;
GRANT ALL ON public.routines TO service_role;
ALTER TABLE public.routines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own routines" ON public.routines FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER routines_updated_at BEFORE UPDATE ON public.routines FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX routines_user_order_idx ON public.routines (user_id, order_index);

-- 3) Exercícios dentro de uma rotina — cada um carrega sua própria progressão
CREATE TABLE public.routine_exercises (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  routine_id uuid NOT NULL REFERENCES public.routines(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  name text NOT NULL,
  muscle_group text NOT NULL,
  search_term_en text,
  is_cardio boolean NOT NULL DEFAULT false,
  current_weight numeric(6,2) NOT NULL DEFAULT 0,
  target_sets integer NOT NULL DEFAULT 3,
  rep_min integer NOT NULL DEFAULT 8,
  rep_max integer NOT NULL DEFAULT 12,
  increment numeric(5,2) NOT NULL DEFAULT 2.5,
  note text,
  order_index integer NOT NULL DEFAULT 0,
  next_suggestion jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.routine_exercises TO authenticated;
GRANT ALL ON public.routine_exercises TO service_role;
ALTER TABLE public.routine_exercises ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own routine exercises" ON public.routine_exercises FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER routine_exercises_updated_at BEFORE UPDATE ON public.routine_exercises FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX routine_exercises_routine_order_idx ON public.routine_exercises (routine_id, order_index);

-- 4) Sessões registradas de um exercício (o "histórico") — cada linha é um treino feito daquele exercício
CREATE TABLE public.exercise_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  routine_exercise_id uuid NOT NULL REFERENCES public.routine_exercises(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  performed_at timestamptz NOT NULL DEFAULT now(),
  sets jsonb NOT NULL, -- [{ "weight": number, "reps": number, "rir": number }]
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.exercise_sessions TO authenticated;
GRANT ALL ON public.exercise_sessions TO service_role;
ALTER TABLE public.exercise_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own exercise sessions" ON public.exercise_sessions FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX exercise_sessions_exercise_date_idx ON public.exercise_sessions (routine_exercise_id, performed_at);
CREATE INDEX exercise_sessions_user_date_idx ON public.exercise_sessions (user_id, performed_at);

-- 5) O modelo antigo de "um plano ativo" não é mais usado — as rotinas o substituem.
DROP TABLE IF EXISTS public.workout_plans;
